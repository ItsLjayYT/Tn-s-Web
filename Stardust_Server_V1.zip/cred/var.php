<?php 
    define("Admin_UsrName", "admin");
    define("Admin_Pass", "admin");
?>